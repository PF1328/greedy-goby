import pygame, pytmx, random

clock = pygame.time.Clock()
center = ['cache/Carte_1.tmx', 'cache/Carte_2.tmx', 'cache/Carte_3.tmx']
up=['cache/Carte_1_haut.tmx', 'cache/Carte_2_haut.tmx', 'cache/Carte_3_haut.tmx']
down=['cache/Carte_1_bas.tmx', 'cache/Carte_2_bas.tmx', 'cache/Carte_3_bas.tmx']
left=['cache/Carte_1_gauche.tmx', 'cache/Carte_2_gauche.tmx', 'cache/Carte_3_gauche.tmx']
right=['cache/Carte_1_droit.tmx', 'cache/Carte_2_droit.tmx', 'cache/Carte_3_droit.tmx']
upleft=['cache/Carte_1_coin_haut_gauche.tmx', 'cache/Carte_2_coin_haut_gauche.tmx', 'cache/Carte_3_coin_haut_gauche.tmx']
upright=['cache/Carte_1_coin_haut_droit.tmx', 'cache/Carte_2_coin_haut_droit.tmx', 'cache/Carte_3_coin_haut_droit.tmx']
downleft=['cache/Carte_1_coin_bas_gauche.tmx', 'cache/Carte_2_coin_bas_gauche.tmx', 'cache/Carte_3_coin_bas_gauche.tmx']
downright=['cache/Carte_1_coin_bas_droit.tmx', 'cache/Carte_2_coin_bas_droit.tmx', 'cache/Carte_3_coin_bas_droit.tmx']



def reformat(room, x):
    scaled = []
    for layer in room.visible_layers:
        if isinstance(layer, pytmx.TiledTileLayer):
            for tile in layer:
                tile_image = room.get_tile_image_by_gid(tile[2])
                walls = room.get_layer_by_name("Walls")
            
                if tile_image:
                    tile_image = pygame.transform.scale(tile_image, (room.tilewidth*x, room.tileheight*x))
                    scaled.append([tile[0], tile[1], tile_image, room.tilewidth*x, room.tileheight*x, walls.data[tile[1]][tile[0]]])
    return scaled


def draw_room(screen, room, x, y, collisions):
    for tile in room:
        i=tile[0]
        j=tile[1]
        tile_image = tile[2]
        width=tile[3]
        height=tile[4]
        wall=tile[5]
        
        screen.blit(tile_image, (x+i * width, y+j * height))
        if x+i * width<=735<=x+i * width+64 and y+j * height<=285<=y+j * height+64 and wall>0:
            collisions[0]=True
        if x+i * width<=765<=x+i * width+64 and y+j * height<=285<=y+j * height+64 and wall>0 :
            collisions[1]=True
        if x+i * width<=735<=x+i * width+64 and y+j * height<=325<=y+j * height+64 and wall>0:
            collisions[2]=True
        if x+i * width<=765<=x+i * width+64 and y+j * height<=325<=y+j * height+64 and wall>0 :
            collisions[3]=True




def load_map(x):

    map=[]
    for i in range(9):
        row=[]
        for j in range(10):
            if j==0:
                if i==0:
                    room=random.choice(upleft)
                elif i==8:
                    room=random.choice(upright)
                else :
                    room=random.choice(up)
            elif j==9:
                if i==0:
                    room=random.choice(downleft)
                elif i==8:
                    room=random.choice(downright)
                else :
                    room=random.choice(down)
            elif i==0:
                room=random.choice(left)
            elif i==8:
                room=random.choice(right)
            else :
                room=random.choice(center)
            tmx_data = pytmx.util_pygame.load_pygame(room)
            row.append(reformat(tmx_data, x))
        map.append(row)
    return map

def draw_map(map, x, y, collisions):
    for i in range(len(map)):
        for j in range(len(map[i])):
            if abs((i-4)*1680 - 70-x)<=1780 and abs((j-8)*1280-340-y)<=2180 :
                draw_room(screen, map[i][j],(i-4)*1680 - 70-x ,(j-9)*1280-340-y, collisions)


pygame.init()
clock=pygame.time.Clock()

scr_height = 1500
scr_width = 600


goby = pygame.image.load('cache/goby_fond_gris.png')
goby = pygame.transform.scale(goby, (40,40))

screen = pygame.display.set_mode((scr_height, scr_width))
pygame.display.set_caption("Greedy goby")
map = load_map(4)


xvlayer,yvlayer=0,0
old_x, old_y = xvlayer, yvlayer
collisions = [False, False,
              False, False]

run = True
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    old_x, old_y = xvlayer, yvlayer
    keys = pygame.key.get_pressed()

    if keys[pygame.K_q]: 
        yvlayer -= 6
    if keys[pygame.K_d]: 
        yvlayer += 6

    collisions = [False, False, False, False]
    draw_map(map, yvlayer, xvlayer, collisions)
    
    for k in collisions :
        if k :
            yvlayer = old_y  

    old_x = xvlayer 
    if keys[pygame.K_z]: 
        xvlayer -= 6
    if keys[pygame.K_s]: 
        xvlayer += 6

    collisions = [False, False, False, False]
    draw_map(map, yvlayer, xvlayer, collisions)
    
    for k in collisions :
        if k :
            xvlayer = old_x  
    
    screen.blit(goby, (735, 285))

    pygame.display.update()
    clock.tick(60)
pygame.quit()
