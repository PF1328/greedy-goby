<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Dungeon Wall Tileset" tilewidth="16" tileheight="16" tilecount="48" columns="8">
 <image source="C:/Users/dumbo/Projet/cache/Dungeon_Wall_Tileset.png" trans="000000" width="128" height="96"/>
</tileset>
